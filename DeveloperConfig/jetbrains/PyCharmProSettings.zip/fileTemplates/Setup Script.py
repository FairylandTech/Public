# coding: utf8
""" 
@File: ${FILE_NAME}
@Author: Alice(From Chengdu.China)
@HomePage: https://github.com/AliceEngineerPro
@CreatedTime: ${DATE} ${TIME}
"""

$Import

setup(
    name='$Package_name',
    version='$Version',
    packages=$PackageList,$PackageDirs
    url='$URL',
    license='$License',
    author='$Author',
    author_email='$Author_Email',
    description='$Description'
)
